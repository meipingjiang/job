<template>
  <div class="hello">
    <h1>{{ msg }}</h1>
    <input v-model="username" placeholder="请输入用户名"/>
    <input v-model="password" type="password" placeholder="请输入密码"/>
    <button v-on:click="login">登录</button>
    <p>用户名：{{username}},密码：{{password}}</p>
  </div>
</template>

<script>
export default {
  name: 'HelloWorld',
  data () {
    return {
      msg: '登录',
      username:"",
      password:""
    }
  },
  methods:{
    login(){
      if(this.username == ""){
        alert("请输入用户名");
        return;
      }
      if(this.password == ""){
        alert("请输入密码");
        return;
      }
    }
  }
}
</script>
