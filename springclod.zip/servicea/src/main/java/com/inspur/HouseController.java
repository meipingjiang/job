package com.inspur;

import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;
import com.netflix.ribbon.proxy.annotation.Hystrix;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

@RestController
public class HouseController {

    @Autowired
    HouseService houseService;

    @RequestMapping(value="/house/{user}",method= RequestMethod.GET)
    public String house(@PathVariable("user") String user) {
        return houseService.house(user);
    }

    @Service
    class HouseService {

        @Autowired
        RestTemplate restTemplate;

        @HystrixCommand(fallbackMethod = "fallback")
        public String house(String user) {
            return restTemplate.getForObject("http://serviceb/house/{0}", String.class,new Object[] {user});
        }

        public String fallback(String user) {
            return "{house: 0}";
        }

    }

}
